﻿namespace SpaBooking.Application
{
    // class trống để làm marker
    public class ApplicationMarker
    {
    }
}