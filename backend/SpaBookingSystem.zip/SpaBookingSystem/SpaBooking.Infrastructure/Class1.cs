﻿namespace SpaBooking.Infrastructure
{
    public class Class1
    {

    }
}
